 
 ## Deployment Methods

### 1. FORK THIS REPO

<a href='https://github.com/hakisolos/Queen_Nikka/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>

### 2. GET SESSION ID HERE
 
<a href="https://apppp-4a1971b28792.herokuapp.com/pair"><img src="https://img.shields.io/badge/QR CODE-green" alt="Click Here to Get QR-Code" width="90"></a>


### DEPLOY ON RENDER

1. If you don't have an account in RENDER, create one and deploy.
    <br>
    <a href='https://dashboard.render.com/select-repo?type=web' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white'/></a>



### DEPLOY ON HEROKU

1. If you don't have an account in Heroku, create one.
    <br>
    <a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>
2. Now deploy.
    <br>
    <a href='https://dashboard.heroku.com/new?template=https://github.com/hakisolos/Queen_Nikka' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>
### DEPLOY ON REPLIT
1. Deploy.
    <br>
    <a href='https://replit.com/github//hakisolos/Queen_Nikka target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>

## THIS SCRIPT IS NOT OPENLY ALLOWED TO USED IN ANY OF YOUR PROJECTS BE WARNED!!! 


  
  #### ```HAKI PROFILE VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/hakisolos/count.svg)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


## Support ME

SUPPORT CHANNEL: <a href="[https://whatsapp.com/channel/0029VaqgxNt5q08c9XMItG3P)"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>


### Please Give One Star ✨ & [follow me notify my updates 💗](https://github.com/hakisolos)
<b>Version -> 1.0.0</b>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
  ## ENJOY!!!;
